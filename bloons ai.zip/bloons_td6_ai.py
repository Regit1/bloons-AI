import numpy as np
import tensorflow as tf
from collections import deque
import random
import cv2
import pytesseract
import pyautogui
import time
import pickle
from pynput.keyboard import Key, Controller
import os
from PIL import Image, ImageEnhance
import pymem
import pymem.process
import pymem.exception
import ctypes
import struct
import pyautogui, keyboard, time, OCR, cv2
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import copy
import importlib, re, math, json
from win32gui import GetWindowText, GetForegroundWindow
import re
import sys
import os
import keyboard as kb
from collections import Counter
import threading


pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Adjust this path as needed
rounds_achieved = []


def show_bar_graph():
    # Count occurrences of each number in the list
    round_counts = Counter(rounds_achieved)
    
    # Create a bar graph
    plt.bar(round_counts.keys(), round_counts.values(), color='blue')
    plt.xlabel('Round Number')
    plt.ylabel('Count')
    plt.title('Round Number Frequency')
    plt.show()

def listen_for_key():
    # Listen for the "P" keypress
    kb.wait('p')
    show_bar_graph()
listener_thread = threading.Thread(target=listen_for_key)
listener_thread.daemon = True
listener_thread.start()

def restart_script():

    print("Restarting the script...")
    os.execv(sys.executable, ['python'] + sys.argv)

class GameRestartException(Exception):
    pass

keyboard = Controller()

class BloonsTD6AI:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95  # Discount rate
        self.epsilon = 1.0  # Exploration rate
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.learning_rate = 0.03
        self.model = self._build_model()

    def _build_model(self):
        model = tf.keras.Sequential([
            tf.keras.layers.Dense(24, input_dim=self.state_size, activation='relu'),
            tf.keras.layers.BatchNormalization(),
            tf.keras.layers.Dense(24, activation='relu'),
            tf.keras.layers.Dropout(0.5),
            tf.keras.layers.Dense(self.action_size, activation='linear')
        ])
        model.compile(loss='mse', optimizer=tf.keras.optimizers.Adam(learning_rate=self.learning_rate))
        return model

    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def act(self, state):
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        act_values = self.model.predict(state)
        return np.argmax(act_values[0])

    def replay(self, batch_size):
        minibatch = random.sample(self.memory, batch_size)
        for state, action, reward, next_state, done in minibatch:
            target = reward
            if not done:
                target = reward + self.gamma * np.amax(self.model.predict(next_state)[0])
            target_f = self.model.predict(state)
            target_f[0][action] = target
            self.model.fit(state, target_f, epochs=1, verbose=0)
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def adjust_epsilon(self, reward, threshold=100):
        if reward < threshold:
            self.epsilon = min(1.0, self.epsilon * 1.01)  # Increase exploration if underperforming
        else:
            self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def save_state(self, filename):
        self.model.save(f"{filename}_model.h5")
        with open(f"{filename}_memory.pickle", "wb") as f:
            pickle.dump(self.memory, f)
        with open(f"{filename}_epsilon.pickle", "wb") as f:
            pickle.dump(self.epsilon, f)

    def load_state(self, filename):
        if os.path.exists(f"{filename}_model.h5"):
            self.model = tf.keras.models.load_model(f"{filename}_model.h5")
        if os.path.exists(f"{filename}_memory.pickle"):
            with open(f"{filename}_memory.pickle", "rb") as f:
                self.memory = pickle.load(f)
        if os.path.exists(f"{filename}_epsilon.pickle"):
            with open(f"{filename}_epsilon.pickle", "rb") as f:
                self.epsilon = pickle.load(f)

def preprocess_image(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
    try:
        pil_img = Image.fromarray(binary)
        enhancer = ImageEnhance.Contrast(pil_img)
        enhanced_img = enhancer.enhance(2.0)
        return np.array(enhanced_img)
    except Exception as e:
        print(f"Error in image enhancement: {e}")
        return binary

def extractIntegerGroups(inputString):
    groups = re.findall(r'\d+', inputString)
    return [int(group) for group in groups]

def flood_fill(image, startCoord = (0, 0)):
    image_uint8 = image.astype(np.uint8)
    image_uint8[0, 0]=255
    mask = np.zeros((image.shape[0] + 2, image.shape[1] + 2), dtype=np.uint8)
    cv2.floodFill(image_uint8, mask, (0, 0), 0, 200, 255, cv2.FLOODFILL_FIXED_RANGE)
    filled_image = image_uint8.astype(image.dtype)
    return filled_image

class GameInterface():
    def __init__(self, agent):
        self.agent = agent
        self.healthIcon = Image.open("Life.png")
        self.moneyIcon = Image.open("Money.png")
        self.roundIcon = Image.open("Round.png")
        self.placed_tower_locations = []
        self.original_tower_locations = [(186, 387), (486, 390), (262, 559), (467, 545), (485, 694),
                                        (665, 717), (661, 546), (653, 373), (733, 300), (911, 527),
                                        (938, 408), (864, 874), (1132, 683), (1148, 473), (1172, 127),
                                        (1501, 314), (1511, 585)]

    
    def analyzeTopbar(self):
        self.topbar = pyautogui.screenshot(region=(0, 0, 1920, 90))
        
        self.healthIconLoc = pyautogui.center(pyautogui.locate(self.healthIcon, self.topbar, confidence=0.747))
        self.moneyIconLoc = pyautogui.center(pyautogui.locate(self.moneyIcon, self.topbar, confidence=0.7))
        self.roundIconLoc = pyautogui.center(pyautogui.locate(self.roundIcon, self.topbar, confidence=0.54))
        
        self.topbarProc = np.array(self.topbar)
        self.topbarProc = self.topbarProc[:,self.healthIconLoc.x+20:self.roundIconLoc.x-50,:]
        self.topbarProc[:40,800:] = 8
        self.topbarProc[:,self.moneyIconLoc.x-self.healthIconLoc.x-40+0:self.moneyIconLoc.x-self.healthIconLoc.x-40+10,:] = 128
        self.topbarGray = cv2.cvtColor(self.topbarProc, cv2.COLOR_BGR2GRAY)
        self.topbarBin = (self.topbarGray > 13) * 255
        self.topbarBin[0,:] = 255
        self.topbarBin[-1,:] = 255
        self.topbarBin[:,0] = 255
        self.topbarBin[:,-1] = 255
        self.numberMask = flood_fill(self.topbarBin)
        self.topbarProc[~(self.numberMask != 0)] = 0
        self.topbarData = OCR.extractText(self.topbarProc, display=False)
        self.topbarData = self.topbarData.replace(",", "").replace(".", "")
        self.topbarData = extractIntegerGroups(self.topbarData)
        
    def perform_restart_actions(self):
        # Save the model state before restarting
        self.agent.save_state('bloons_td6_model_restart')
        self.original_tower_locations = self.placed_tower_locations
        self.placed_tower_locations = []

        
        time.sleep(5)
        keyboard.press(Key.alt_r)
        time.sleep(0.1)
        keyboard.release(Key.alt_r)
        keyboard.press(Key.enter)
        time.sleep(0.1)
        keyboard.release(Key.enter)
        pyautogui.click(869, 821)
        time.sleep(1)
        keyboard.press(Key.enter)
        time.sleep(0.1)
        keyboard.release(Key.enter)
        time.sleep(2)
        keyboard.press(Key.space)
        time.sleep(0.1)
        keyboard.release(Key.space)
        time.sleep(2)
        pyautogui.click(969, 913)
        time.sleep(2)
        pyautogui.click(1201, 855)
        time.sleep(1)
        keyboard.press(Key.enter)
        time.sleep(0.1)
        keyboard.release(Key.enter)
        time.sleep(2)
        keyboard.press(Key.space)
        time.sleep(0.1)
        keyboard.release(Key.space)

    def getHealth(self):
        try:
            return self.topbarData[0]
        except:
            print("Error retrieving health data. Restarting script...")
            self.perform_restart_actions()
            raise GameRestartException("Restarting due to health detection failure")

    def getMoney(self):
        try:
            return self.topbarData[1]
        except IndexError:
            print("Error retrieving money data. Restarting script...")
            self.perform_restart_actions()
            raise GameRestartException("Restarting due to money detection failure")

    def getRound(self):
        try:
            return self.topbarData[-2]
        except IndexError:
            print("Error retrieving round data. Restarting script...")
            self.perform_restart_actions()
            raise GameRestartException("Restarting due to round detection failure")

def get_memory_state():
    try:
        pm = pymem.Pymem('BloonsTD6.exe')
        life_address = 0x1ED4DF85B18
        round_address = 0x1ED4DF85B18
        print(f"Life Address: {life_address}")
        print(f"Round Address: {round_address}")
        life = pm.read_double(life_address)
        current_round = pm.read_double(round_address)
        print(f"Read Life Value: {life}")
        print(f"Read Round Value: {current_round}")
        return life, current_round
    except Exception as e:
        print(f"An error occurred: {e}")
    return 0, 0

def calculate_reward(prev_life, current_life, prev_round, current_round, prev_money, current_money):
    reward = 0
    lifemult = 0
    if current_life < prev_life:
        lifemult = prev_life - current_life
        reward -= 100 * lifemult
        print("its feeling pain")
        print(current_life)
    if current_round > prev_round:
        reward += 50
        print("its feeling happiness")
    
    # New money-based rewards
    if current_money > 1000 and prev_money <= 1000:
        reward += 1
        print("its feeling a bit richer")
    if current_money > 5000 and prev_money <= 5000:
        reward += 5
        print("its feeling quite rich")
    if current_money > 20000 and prev_money <= 20000:
        reward += 15
        print("its feeling extremely wealthy")
    
    return reward

def take_action(action, game):
    num_towers = 25
    num_coordinates = 17
    num_upgrade_paths = 3
    life, current_round, money = get_screen_state(game)
    if life == 0:
        time.sleep(5)
        pyautogui.click(869, 821)
        time.sleep(1)
        keyboard.press(Key.enter)
        time.sleep(0.1)
        keyboard.release(Key.enter)
        time.sleep(2)
        keyboard.press(Key.space)
        time.sleep(0.1)
        keyboard.release(Key.space)
    if random.random() < 0.3:
        tower_action = random.randint(0, num_towers - 1)
        coord_action = random.randint(0, num_coordinates - 1)
        tower_hotkeys = list('abcdefghijklmnoqrstuvwxyz')
        action_coords = [
            (186, 387), (486, 390), (262, 559), (467, 545), (485, 694),
            (665, 717), (661, 546), (653, 373), (733, 300), (911, 527),
            (938, 408), (864, 874), (1132, 683), (1148, 473), (1172, 127),
            (1501, 314), (1511, 585),
        ]

        loop_count = 0
        while (action_coords[coord_action][0], action_coords[coord_action][1]) in game.placed_tower_locations:
            coord_action = random.randint(0, num_coordinates - 1)
            loop_count += 1
            if loop_count > 10:
                print("Unable to find an available tower placement location. Skipping tower placement.")
                return life, current_round, money

        x, y = action_coords[coord_action]
        tower_hotkeys = list('abcdefghijklmnoqrstuvwxyz')
        tower_key = tower_hotkeys[tower_action]

        if tower_key == 'q' and money >= 200:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        elif tower_key == 'a' and money >= 325:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        elif tower_key == 'b' and money >= 1600:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        elif tower_key == 'c' and money >= 160000:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        elif tower_key == 'd' and money >= 400:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        elif tower_key == 'e' and money >= 375:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        elif tower_key == 'f' and money >= 550:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'g' and money >= 400:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))


        elif tower_key == 'g' and money >= 400:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
            
        elif tower_key == 'h' and money >= 1000000:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'i' and money >= 250:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'j' and money >= 1000:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'k' and money >= 1200:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'l' and money >= 350:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'm' and money >= 850:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'n' and money >= 750:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'o' and money >= 600:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'r' and money >= 260:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 's' and money >= 2500:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 't' and money >= 500:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'u' and money >= 600:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'v' and money >= 800:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'w' and money >= 315:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'x' and money >= 75000000:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'y' and money >= 225:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))

        elif tower_key == 'z' and money >= 350:
            print(f"Pressing tower key: {tower_key}")
            keyboard.press(tower_key)
            time.sleep(0.2)
            keyboard.release(tower_key)
            pyautogui.click(x, y)
            time.sleep(0.1)
            pyautogui.click(1602, 120)
            print(f"Clicking at coordinates: ({x}, {y})")
            time.sleep(0.1)
            pyautogui.click(x, y)
            game.placed_tower_locations.append((x, y))
        else:
            print(f"Insufficient funds to place tower with key {tower_key}.")
        """print(f"Pressing tower key: {tower_key}")
        keyboard.press(tower_key)
        time.sleep(0.2)
        keyboard.release(tower_key)
        pyautogui.click(x, y)
        time.sleep(0.1)
        pyautogui.click(1602, 120)
        print(f"Clicking at coordinates: ({x}, {y})")
        time.sleep(0.1)
        pyautogui.click(x, y)
        game.placed_tower_locations.append((x, y))"""
    else:
        if random.random() < 0.3 or not game.original_tower_locations:
            upgrade_action = random.randint(0, num_towers * num_upgrade_paths - 1)
            tower_to_upgrade = upgrade_action // num_upgrade_paths
            upgrade_path = upgrade_action % num_upgrade_paths
            select_tower_key = [str(i) for i in range(1, 26)]
            upgrade_keys = [',', '.', '/']
            try:
                print(f"Selecting ability: {select_tower_key[tower_to_upgrade]}")
                keyboard.press(select_tower_key[tower_to_upgrade])
                time.sleep(0.2)
                keyboard.release(select_tower_key[tower_to_upgrade])
                
                # Move mouse to the location of the selected tower
                if game.placed_tower_locations:
                    target_location = game.placed_tower_locations[tower_to_upgrade]
                    print(f"Moving mouse to: {target_location}")
                    pyautogui.moveTo(target_location[0], target_location[1])
                    time.sleep(0.1)
                    pyautogui.leftClick
                    time.sleep(0.2)  # Optional delay
                
                print(f"Upgrading path: {upgrade_keys[upgrade_path]}")
                keyboard.press(upgrade_keys[upgrade_path])
                time.sleep(0.2)
                keyboard.release(upgrade_keys[upgrade_path])
            except IndexError:
                print(f"Error: Invalid tower index {tower_to_upgrade}. Skipping upgrade.")
        else:
            time.sleep(0.5)
            print("idle for 2")
    time.sleep(0.2)
    return get_screen_state(game)

def get_screen_state(game):
    try:
        game.analyzeTopbar()
        life = game.getHealth()
        current_round = game.getRound()
        money = game.getMoney()
        print(f"Life: {life}, Round: {current_round}, Money: {money}")
        return life, current_round, money
    except GameRestartException:
        return None, None, None

def main_training_loop():
    state_size = 3  # Life, current round, and money
    action_size = 5  # This would depend on the possible actions in the game
    agent = BloonsTD6AI(state_size, action_size)
    game = GameInterface(agent)

    episodes = 1000

    for e in range(episodes):
        try:
            # Retrieve game state using OCR-based methods
            life, current_round, money = get_screen_state(game)
            if life is None or current_round is None or money is None:
                raise GameRestartException("Restart triggered in get_screen_state")

            state = np.reshape([life, current_round, money], [1, state_size])
            total_reward = 0

            for time_step in range(500):  # Assuming max 500 steps per episode
                action = agent.act(state)
                prev_life, prev_round, prev_money = life, current_round, money

                try:
                    life, current_round, money = take_action(action, game)
                except Exception as ex:
                    print(f"Error in take_action: {ex}")
                    life, current_round, money = prev_life, prev_round, prev_money
                    continue  # Skip to next iteration if there's an error

                if life is None or current_round is None or money is None:
                    raise GameRestartException("Restart triggered in take_action")

                print(f"Life: {life}, Round: {current_round}, Money: {money}")

                if current_round > prev_round:
                    if current_round < 100:
                        rounds_achieved.append(current_round)
                print("rounds achieved: ", rounds_achieved)

                next_state = np.reshape([life, current_round, money], [1, state_size])
                reward = calculate_reward(prev_life, life, prev_round, current_round, prev_money, money)
                total_reward += reward

                done = life <= 0 or current_round >= 60
                agent.remember(state, action, reward, next_state, done)
                state = next_state

                if done:
                    print(f"Episode: {e}/{episodes}, Steps: {time_step}, Total Reward: {total_reward}")
                    break

            if len(agent.memory) > 32:
                agent.replay(32)

        except GameRestartException as e:
            print(f"Caught restart exception: {e}")
            game.perform_restart_actions()
            continue
        except Exception as ex:
            print(f"Unexpected error: {ex}")
            game.perform_restart_actions()
            continue

    agent.save_state('bloons_td6_model_final')
    return "complete"

if __name__ == "__main__":
    while True:
        result = main_training_loop()
        if result == "complete":
            print("Training completed successfully.")
            break
        elif result == "restart":
            print("Restarting the script...")
            time.sleep(5)  # Wait for 5 seconds before restarting
            continue
        else:
            print("Unexpected result. Exiting.")
            break