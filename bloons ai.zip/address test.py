from pymem import Pymem
import time
import struct

def scan_for_double(pm, value):
    pattern = struct.pack('d', value)
    addresses = pm.pattern_scan_all(pattern)
    # Check if addresses is an integer (single address) or a list
    if isinstance(addresses, int):
        return [addresses]
    return addresses or []  # Return an empty list if addresses is None

def find_life_address():
    pm = Pymem("BloonsTD6.exe")  # Replace with the actual process name
    
    print("Scanning for initial life value (150)...")
    initial_addresses = scan_for_double(pm, 150.0)
    print(f"Found {len(initial_addresses)} potential addresses")
    
    # Wait for 23 seconds
    print("Waiting for 23 seconds...")
    time.sleep(23)
    
    print("Scanning for new life value (130)...")
    new_addresses = scan_for_double(pm, 130.0)
    print(f"Found {len(new_addresses)} potential addresses")
    
    # Find common addresses
    common_addresses = set(initial_addresses) & set(new_addresses)
    
    if common_addresses:
        print(f"Potential life value address(es): {common_addresses}")
        return list(common_addresses)
    else:
        print("No matching addresses found. The life value may be stored differently or has changed.")
        return []

# Run the scan
try:
    life_addresses = find_life_address()
    if life_addresses:
        print("Verify these addresses in the game to confirm the correct one.")
    else:
        print("No addresses found. You may need to adjust the scan parameters.")
except Exception as e:
    print(f"An error occurred: {e}")
    print("Make sure the game is running and the process name is correct.")