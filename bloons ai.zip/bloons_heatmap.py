import bloons_td6_ai
import OCR

import numpy as np
import matplotlib.pyplot as plt
from pynput import keyboard
import seaborn as sns

class BloonsHeatmap:
    def __init__(self):
        self.bloons_heatmap = []
        self.keyboard_listener = keyboard.Listener(on_press=self.on_press)
        self.keyboard_listener.start()

    def add_rounds(self, rounds_achieved):
        self.bloons_heatmap.extend(rounds_achieved)

    def generate_heatmap(self):
        if not self.bloons_heatmap:
            print("No data to generate heatmap.")
            return

        # Create a 2D array to represent the heatmap
        max_round = max(self.bloons_heatmap)
        heatmap_data = np.zeros((8, 10))  # Assuming max 80 rounds, adjust if needed

        # Populate the heatmap data
        for round_num in self.bloons_heatmap:
            row = (round_num - 1) // 10
            col = (round_num - 1) % 10
            heatmap_data[row, col] += 1

        # Create the heatmap
        plt.figure(figsize=(12, 8))
        sns.heatmap(heatmap_data, annot=True, fmt='d', cmap='YlOrRd')
        plt.title('Bloons TD6 Rounds Achieved Heatmap')
        plt.xlabel('Round (1-10)')
        plt.ylabel('Round (10s place)')
        plt.show()

    def on_press(self, key):
        if key == keyboard.Key.up:
            self.generate_heatmap()
        elif key == keyboard.Key.esc:
            # Stop listener
            return False

if __name__ == "__main__":
    heatmap = BloonsHeatmap()

    # Example usage:
    # This would typically be called from your main script
    # heatmap.add_rounds([1, 2, 3, 5, 5, 10, 15, 20, 20, 20, 25, 30])

    print("Press the up arrow key to generate the heatmap.")
    print("Press ESC to exit.")

    # Keep the script running
    heatmap.keyboard_listener.join()