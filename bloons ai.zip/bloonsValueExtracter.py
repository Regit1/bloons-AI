import ctypes
import win32api
import win32process
import psutil
import time

# Define the data type of the value stored at the memory address
value_type = ctypes.c_int

# Define the name of the target process
target_process_name = "BloonsTD6.exe"  # Replace with the actual process name

# Store the process ID of the target process
target_process_id = None

# Function to find the process ID by name
def find_process_id(process_name):
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == process_name:
            return proc.info['pid']
    return None

# Function to read value from a memory address in the target process
def read_memory_value(process_handle, memory_address):
    value = ctypes.c_int()
    win32process.ReadProcessMemory(process_handle, memory_address, ctypes.byref(value), ctypes.sizeof(value), None)
    return value.value

# Main function to continuously read and update the value
def main():
    global target_process_id

    # Continuously run the loop
    while True:
        # Find the process ID if not already obtained
        if target_process_id is None:
            target_process_id = find_process_id(target_process_name)

        # Check if the target process is running
        if target_process_id is not None and psutil.pid_exists(target_process_id):
            try:
                # Open the target process
                process_handle = win32api.OpenProcess(win32api.PROCESS_ALL_ACCESS, False, target_process_id)

                # Define the memory address you want to read from
                memory_address = 0x22EFD6BDC08  # Replace with the actual memory address

                # Read the value from the memory address in the target process
                value = read_memory_value(process_handle, memory_address)

                # Print the retrieved value
                print(value)

                # Close the process handle
                win32api.CloseHandle(process_handle)

            except Exception as e:
                print(f"Error: {str(e)}")

        # Sleep for a certain duration before the next iteration
        # Adjust the delay according to your needs
        time.sleep(0.1)

if __name__ == '__main__':
    main()